#include <vector>
#include <immintrin.h>
#include <random>
#include <iostream>
#include <cstdlib>   // Random
#include <algorithm> // std::mins
#include <string.h>
#include "Eval-perf.h"
#include "exo16.h"
#include "exo21.h"
#include "exo22.h"

int main()
{


}