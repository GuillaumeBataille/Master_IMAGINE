#include <vector>
#include <immintrin.h>
#include <random>
#include <iostream>
#include <cstdlib> // Random
#include <algorithm> // std::mins
#include "Eval-perf.h"

int32_t reduceAdd(std::vector<int32_t> tab){
    
    int32_t res = 0;
    
    for(int32_t val : tab){
        res += val;
    }

    return res;
}

double reduceMul(std::vector<double> tab){
    
    double res = 1;
    
    for(double val : tab){
        res *= val;
    }

    return res;
}

double doubleReduceMulSIMD(std::vector<double> tab){
    __m256d vec1 = _mm256_loadu_pd(tab.data());
    __m256d vec2;
    double storedRes[4];
    double res;

    size_t i = 4;
    for(;i < tab.size() - 3; i = i+4){
        vec2 = _mm256_loadu_pd(tab.data() + i);

        vec1 = _mm256_mul_pd(vec1, vec2);
    }

    _mm256_storeu_pd(storedRes, vec1);
    res = storedRes[0] * storedRes[1] * storedRes[2] * storedRes[3];

    for(;i < tab.size(); i++){
        res *= tab[i];
    }
    
    return res;
}

   


int32_t int32ReduceAddSIMD(std::vector<int32_t> tab){
    __m256i vec1 = _mm256_loadu_si256((__m256i *)tab.data());
    __m256i vec2;
    int32_t storedRes[8];
    int32_t res;

    size_t i = 8;
    for(;i < tab.size() - 7; i = i+8 ){
        vec2 = _mm256_loadu_si256((__m256i *)tab.data() + i);

        vec1 = _mm256_add_epi32(vec1, vec2);
    }

    _mm256_storeu_si256((__m256i *)storedRes, vec1);
    res = storedRes[0] + storedRes[1] + storedRes[2] + storedRes[3]
    + storedRes[4] + storedRes[5] + storedRes[6] + storedRes[7];

    for(;i < tab.size(); i++){
        res += tab[i];
    }
    
    return res;
}

unsigned int flop_reduce(int n, int taille){
 return n*taille;
};



/*
Question 10. Pour un reduce 10 000 000 fois

Mult double classique avec fno tree vectorize:
CPI: 38.9547
IPC: 0.0256708

Mult double classique avec les options SIMD:
CPI: 0.214308
IPC: 4.66618

Mult double SIMD avec les options SIMD:
CPI: 0.0762697
IPC: 13.1114

Add int32 classique avec fno tree vectorize:
CPI: 315.638
IPC: 0.00316819

Add int32 classique avec les options SIMD:
CPI: 0.966603
IPC: 1.03455

Add int32 SIMD avec les options SIMD:
CPI: 0.735934
IPC: 1.35882

*/

float min(std::vector<float> tab){
    float res;
    res = tab[0];
    for (size_t i = 0; i< tab.size() ; i++){
        if(res < tab[i]) res = tab[i];
    }
    return res;
}

float min_withlib(std::vector<float> tab){

    return *std::min_element(tab.data(),tab.data()+tab.size());
}

float floatMinSIMD(std::vector<float> tab){
    // Pour float type = __m256 et load = _mm256_loadu_ps
    __m256 vec1 = _mm256_loadu_ps(tab.data());
    __m256 vec2;
    float storedRes[8];
    float res;

    size_t i = 8;
    for(;i < tab.size() - 7; i = i+8){
        vec2 = _mm256_loadu_ps(tab.data() + i);

        vec1 = _mm256_min_ps(vec1, vec2); // Compare les pairs vec1/vec2 et on mets dans vec1 les min
    }

    _mm256_storeu_ps(storedRes, vec1);
     
    res = storedRes[0];
    
    for (size_t j=1; j < 8 ; j++){
        if(res > storedRes[j]) res = storedRes[j];
    }
   
    for(;i < tab.size(); i++){
        if(res > storedRes[i]) res = storedRes[i];
    }
    
    return res;
}

std::vector<float> generate_rand_float_tab(unsigned int taille){
    std::vector<float> res;
    res.resize(taille,0.);
    for (size_t i = 0; i< res.size(); i++){
        res[i]= rand()%50000000;
    }
    return res;
}
/* Question 11 avec des vecteur float de taille 1 000 000

min float classique avec fno tree vectorize:
CPI: 0.255545
IPC: 3.9132

min float classique avec les options SIMD:
CPI: 0.0193462
IPC: 51.6896

min SIMD avec les options SIMD:
CPI: 0.018452
IPC: 54.1947

min avec std::min_element + options SIMD:
CPI: 0.0195798
IPC: 51.073

*/


std::vector<double> generate_rand_double_tab(unsigned int taille){
    std::vector<double> res;
    res.resize(taille,0.);
    for (size_t i = 0; i< res.size(); i++){
        res[i]= rand()%50000000;
    }
    return res;
}

// Ordre : i j k 
std::vector<double> Matrix_double_mult_1(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){
        for(size_t i=0 ; i < n; i++){
            for(size_t j = 0; j < n; j++){
                for (size_t k = 0; k < n; k++){
                    C[i*n+j] += A[i*n+k] * B[k*n+j];
                    
                }
            }
        }
    return C;
}

// Ordre : i k j
std::vector<double> Matrix_double_mult_2(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

        for(size_t i = 0; i < n ; i++){
            for(size_t k = 0; k < n; k++){
                for (size_t j = 0; j < n; j++){
                    C[i*n+j] += A[i*n+k] + B[k*n+j];
                    
                }
            }
        }
    return C;
}

// Ordre : k j i
std::vector<double> Matrix_double_mult_3(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

        for(size_t k = 0; k < n; k++){
            for(size_t j = 0; j < n; j++){
                for (size_t i = 0; i < n; i++){
                    C[i*n+j] += A[i*n+k] + B[k*n+j];
                    
                }
            }
        }
    return C;
}

// Ordre : j i k
std::vector<double> Matrix_double_mult_4(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

        for(size_t j = 0; j < n; j++){
            for(size_t i = 0; i < n; i++){
                for (size_t k = 0; k < n; k++){
                    C[i*n+j] += A[i*n+k] + B[k*n+j];
                    
                }
            }
        }
    return C;
}

// Ordre : k i j 
std::vector<double> Matrix_double_mult_5(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

        for(size_t k = 0; k < n; k++){
            for(size_t i = 0; i < n; i++){
                for (size_t j = 0; j < n; j++){
                    C[i*n+j] += A[i*n+k] + B[k*n+j];
                    
                }
            }
        }
    return C;
}

// Ordre : j k i
std::vector<double> Matrix_double_mult_6(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

        for(size_t j = 0; j < n; j++){
            for(size_t k = 0; k < n; k++){
                for (size_t i = 0; i < n; i++){
                    C[i*n+j] += A[i*n+k] + B[k*n+j];
                    
                }
            }
        }
    return C;
}


std::vector<double> Matrix_double_mult_SIMD(std::vector<double> A,std::vector<double> B, std::vector<double> C, unsigned int n){

    __m256d vecA;
    __m256d vecB;
    __m256d vecC;

           for(size_t i=0; i < n; i++){
            for(size_t j=0; j < n; j+=4){
                vecC = _mm256_loadu_pd(C.data()+i*n+j); // On récupère le vecteur de taille 4 resultant courant C[i*n+j];
                for (size_t k=0; k < n; k++){
                   //std::cout << "i :" <<i <<" j : "<< j << " k : "<< k << " A[i*n+k] = "<< A[i*n+k] <<std::endl;
                        vecA = _mm256_set1_pd(A[i*n+k]); // On recupère le vecteur set avec les valeurs de A[i*n,k] partout
                        vecB = _mm256_loadu_pd(B.data()+k*n+j); // On récupère le vecteur de taille 4 courant débutant a B[k*n+j];

                    vecC = _mm256_fmadd_pd(vecA,vecB,vecC);
                   _mm256_storeu_pd(C.data()+i*n+j,vecC); // On ajoute notre somme FMA dans le vect resultat C;

                }

            }
        }
    return C;

}


// Question 13 
/*
13.1. On a une matrice (i,j) de taille m lignes *n colonnes avec i = ligne et j = colonnes
    et on a notre vecteur(x) unidimentionnel de taille n*m.
    Pour retrouver un élément a l'indice i,j, il faut :
    - parcourir n*i (n fois le nombre d'élément d'une ligne)
    - parcourir j éléménet pour accéder à la colonne souhaité 

    Ce qui nous donne M[i,j] = V[i*n + j];

13.2. test avec deux matrices (1,2,3,4) de taille n*n (n = 2)
 mat_carré 0 : 1
 mat_carré 1 : 2
 mat_carré 2 : 3
 mat_carré 3 : 4

 mat_res 0 : 7
 mat_res 1 : 10
 mat_res 2 : 15
 mat_res 3 : 22 // Valide

// Pour n = 1000 sans optimisation () et N = 2*(n*n*n)
1:
CPI: 14.4197
IPC: 0.0693494

2:
CPI: 13.8366
IPC: 0.072272

3:
CPI: 19.6217
IPC: 0.0509639

4:
CPI: 20.338
IPC: 0.049169

5:
CPI: 17.5249
IPC: 0.0570615

6:
CPI: 17.8895
IPC: 0.0558987


Le meilleur semble être le 2 (Ordre i k j) avec le 1 qui s'en rapproche (Ordre k i j)
Ce qui semble cohérent car J c'est le plus profond dans le parcours des matrices;

13.3.
MultMat version SIMD et FMA sans l'option SIMD:
CPI: 10.4749
IPC: 0.0954664

Donc bien plus performant que le reste au dessus.

13.4. avec le SIMD option activé , on constate que tout ce vaut plus ou moins:
    Donc cela signifie que le compilateur parallelise naturellement.

*/

//Question 14

std::vector<int64_t> int64t_transpose (std::vector<int64_t> mat){
    std::vector<int64_t> mat_res;

    
    return mat_res;
} 

int main(){
    std::vector<double> vec = {8, 2, 4, 2, 6, 10, 8, 4, 6, 1, 6};
    std::vector<int32_t> vec_int = {8, 2, 4, 2, 6, 10, 8, 4, 6, 1, 6};
    
    int n = 64;
    int nbBoucle = 10;
    //std::vector<float> vec_rand = generate_rand_float_tab(100000000);
    std::vector<double> mat_A;
    mat_A = generate_rand_double_tab(n*n);
    std::vector<double> mat_B; 
    mat_B= generate_rand_double_tab(n*n);
    std::vector<double> mat_res;
    //mat_A.resize(n*n,2.);
    //mat_B.resize(n*n,2.);
    std::vector<double> mat_C; mat_C.resize(n*n,0.);
    int N;

    EvalPerf PE;

    PE.start();
    //Q10
    /*for(size_t i = 0; i < nbBoucle; i++){
        //doubleReduceMulSIMD(vec);
        //int32ReduceAddSIMD(vec_int);
        //reduceMul(vec);   
        //reduceAdd(vec_int);
        
    }*/
    // Q11 
    /*//min(vec_rand);
    //floatMinSIMD(vec_rand);
    //min_withlib(vec_rand);*/

    //Q12
    // TODO 

    //Q13
    //13.2

    //Matrix_double_mult_1(mat_A,mat_B,mat_C,n);
    //Matrix_double_mult_2(mat_A,mat_B,mat_C,n);
    //Matrix_double_mult_3(mat_A,mat_B,mat_C,n);
    //Matrix_double_mult_4(mat_A,mat_B,mat_C,n);
    //Matrix_double_mult_5(mat_A,mat_B,mat_C,n);
    //Matrix_double_mult_6(mat_A,mat_B,mat_C,n);
    // 13.3
    //mat_res = Matrix_double_mult_SIMD(mat_A,mat_B,mat_C,n);

    //Q14
    

    PE.stop();
    
    N = 2*(n*n*n);
    //N = PE.Gflops(100000000);
    //N = flop_reduce(nbBoucle,vec.size());
    //N = flop_reduce(nbBoucle,vec_int.size());
    std::cout << "nb cycles: " << PE.nb_cycle() << std::endl;
    std::cout << "nb secondes: " << PE.second() << std::endl;
    std::cout << "nb millisecondes: " << PE.millisecond() << std::endl;
    std::cout << "CPI: " << PE.CPI(N) << std::endl;
    std::cout << "IPC: " << PE.IPC(N) << std::endl;
    //std::cout << int32ReduceAddSIMD(vec) << std::endl;
}