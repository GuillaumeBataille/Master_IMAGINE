#include <vector>
#include <immintrin.h>
#include <random>
#include <iostream>
#include <cstdlib> // Random
#include <algorithm> // std::mins
#include "Eval-perf.h"

int32_t reduceAdd(std::vector<int32_t> tab){
    
    int32_t res = 0;
    
    for(int32_t val : tab){
        res += val;
    }

    return res;
}

double reduceMul(std::vector<double> tab){
    
    double res = 1;
    
    for(double val : tab){
        res *= val;
    }

    return res;
}

double doubleReduceMulSIMD(std::vector<double> tab){
    __m256d vec1 = _mm256_loadu_pd(tab.data());
    __m256d vec2;
    double storedRes[4];
    double res;

    size_t i = 4;
    for(;i < tab.size() - 3; i = i+4){
        vec2 = _mm256_loadu_pd(tab.data() + i);

        vec1 = _mm256_mul_pd(vec1, vec2);
    }

    _mm256_storeu_pd(storedRes, vec1);
    res = storedRes[0] * storedRes[1] * storedRes[2] * storedRes[3];

    for(;i < tab.size(); i++){
        res *= tab[i];
    }
    
    return res;
}

   


int32_t int32ReduceAddSIMD(std::vector<int32_t> tab){
    __m256i vec1 = _mm256_loadu_si256((__m256i *)tab.data());
    __m256i vec2;
    int32_t storedRes[8];
    int32_t res;

    size_t i = 8;
    for(;i < tab.size() - 7; i = i+8 ){
        vec2 = _mm256_loadu_si256((__m256i *)tab.data() + i);

        vec1 = _mm256_add_epi32(vec1, vec2);
    }

    _mm256_storeu_si256((__m256i *)storedRes, vec1);
    res = storedRes[0] + storedRes[1] + storedRes[2] + storedRes[3]
    + storedRes[4] + storedRes[5] + storedRes[6] + storedRes[7];

    for(;i < tab.size(); i++){
        res += tab[i];
    }
    
    return res;
}

unsigned int flop_reduce(int n, int taille){
 return n*taille;
};



/*
Question 10. Pour un reduce 10 000 000 fois

Mult double classique avec fno tree vectorize:
CPI: 38.9547
IPC: 0.0256708

Mult double classique avec les options SIMD:
CPI: 0.214308
IPC: 4.66618

Mult double SIMD avec les options SIMD:
CPI: 0.0762697
IPC: 13.1114

Add int32 classique avec fno tree vectorize:
CPI: 315.638
IPC: 0.00316819

Add int32 classique avec les options SIMD:
CPI: 0.966603
IPC: 1.03455

Add int32 SIMD avec les options SIMD:
CPI: 0.735934
IPC: 1.35882

*/

float min(std::vector<float> tab){
    float res;
    res = tab[0];
    for (size_t i = 0; i< tab.size() ; i++){
        if(res < tab[i]) res = tab[i];
    }
    return res;
}

float min_withlib(std::vector<float> tab){

    return *std::min_element(tab.data(),tab.data()+tab.size());
}

float floatMinSIMD(std::vector<float> tab){
    // Pour float type = __m256 et load = _mm256_loadu_ps
    __m256 vec1 = _mm256_loadu_ps(tab.data());
    __m256 vec2;
    float storedRes[8];
    float res;

    size_t i = 8;
    for(;i < tab.size() - 7; i = i+8){
        vec2 = _mm256_loadu_ps(tab.data() + i);

        vec1 = _mm256_min_ps(vec1, vec2); // Compare les pairs vec1/vec2 et on mets dans vec1 les min
    }

    _mm256_storeu_ps(storedRes, vec1);
     
    res = storedRes[0];
    
    for (size_t j=1; j < 8 ; j++){
        if(res > storedRes[j]) res = storedRes[j];
    }
   
    for(;i < tab.size(); i++){
        if(res > storedRes[i]) res = storedRes[i];
    }
    
    return res;
}

std::vector<float> generate_rand_float_tab(unsigned int taille){
    std::vector<float> res;
    res.resize(taille,0.);
    for (size_t i = 0; i< res.size(); i++){
        res[i]= rand()%50000000;
    }
    return res;
}
/* Question 11 avec des vecteur float de taille 1 000 000

min float classique avec fno tree vectorize:
CPI: 0.255545
IPC: 3.9132

min float classique avec les options SIMD:
CPI: 0.0193462
IPC: 51.6896

min SIMD avec les options SIMD:
CPI: 0.018452
IPC: 54.1947

min avec std::min_element + options SIMD:
CPI: 0.0195798
IPC: 51.073

*/

// Question 13 
/*
1. On a une matrice (i,j) de taille m lignes *n colonnes avec i = ligne et j = colonnes
    et on a notre vecteur(x) unidimentionnel de taille n*m.
    Pour retrouver un élément a l'indice i,j, il faut :
    - parcourir n*i (n fois le nombre d'élément d'une ligne)
    - parcourir j éléménet pour accéder à la colonne souhaité 

    Ce qui nous donne M[i,j] = V[i*n + j];

*/

// Ordre :
std::vector<double> Matrix_float_mult_1(std::vector<float> A,std::vector<float> B,std::vector<float> C){}

// Ordre :
std::vector<double> Matrix_float_mult_2(std::vector<float> A,std::vector<float> B,std::vector<float> C){}

// Ordre :
std::vector<double> Matrix_float_mult_3(std::vector<float> A,std::vector<float> B,std::vector<float> C){}

// Ordre :
std::vector<double> Matrix_float_mult_4(std::vector<float> A,std::vector<float> B,std::vector<float> C){}

// Ordre :
std::vector<double> Matrix_float_mult_5(std::vector<float> A,std::vector<float> B,std::vector<float> C){}

// Ordre :
std::vector<double> Matrix_float_mult_6(std::vector<float> A,std::vector<float> B,std::vector<float> C){}


int main(){
    std::vector<double> vec = {8, 2, 4, 2, 6, 10, 8, 4, 6, 1, 6};
    std::vector<int32_t> vec_int = {8, 2, 4, 2, 6, 10, 8, 4, 6, 1, 6};
    int nbBoucle = 1000000;
    std::vector<float> vec_rand = generate_rand_float_tab(nbBoucle);
    int N;

    EvalPerf PE;

    PE.start();
    //Q10
    /*for(size_t i = 0; i < nbBoucle; i++){
        //doubleReduceMulSIMD(vec);
        //int32ReduceAddSIMD(vec_int);
        //reduceMul(vec);   
        //reduceAdd(vec_int);
        
    }*/
    // Q11 
    /*//min(vec_rand);
    //floatMinSIMD(vec_rand);
    //min_withlib(vec_rand);*/

    //Q12
    // TODO

    //Q13

    
    PE.stop();
    

    N = PE.Gflops(nbBoucle);
    //N = flop_reduce(nbBoucle,vec.size());
    //N = flop_reduce(nbBoucle,vec_int.size());
    std::cout << "nb cycles: " << PE.nb_cycle() << std::endl;
    std::cout << "nb secondes: " << PE.second() << std::endl;
    std::cout << "nb millisecondes: " << PE.millisecond() << std::endl;
    std::cout << "CPI: " << PE.CPI(N) << std::endl;
    std::cout << "IPC: " << PE.IPC(N) << std::endl;
    //std::cout << int32ReduceAddSIMD(vec) << std::endl;
}